-- Part A: High-value vs. Low-value customer profiles
SELECT 
    Value_Tier,
    COUNT("Customer ID") AS Customer_Count,
    AVG(Age) AS Avg_Age,
    AVG("Purchase Amount (USD)") AS Avg_Order_Value,
    AVG("Previous Purchases") AS Avg_Previous_Purchases,
    AVG(CLV_Proxy) AS Avg_CLV,
    AVG("Review Rating") AS Avg_Review_Rating
FROM cleaned_customer_data
GROUP BY Value_Tier
ORDER BY Avg_CLV DESC;

-- Part B: Profiles with the strongest repeat purchase behavior
SELECT 
    Retention_Segment,
    Promo_Segment,
    AVG("Previous Purchases") AS Avg_Previous_Purchases,
    COUNT("Customer ID") AS Customer_Count
FROM cleaned_customer_data
GROUP BY Retention_Segment, Promo_Segment
ORDER BY Avg_Previous_Purchases DESC;

-- QUESTION 2: Which seasons and categories are associated with lower-tenure 

WITH Customer_Tenure AS (
    SELECT 
        Season,
        Category,
        CASE 
            WHEN "Previous Purchases" <= 15 THEN 'Low Tenure / Low Purchases'
            WHEN "Previous Purchases" BETWEEN 16 AND 35 THEN 'Medium Tenure'
            ELSE 'High Tenure / High Purchases'
        END AS Tenure_Level,
        "Customer ID"
    FROM cleaned_customer_data
)
SELECT 
    Season,
    Category,
    Tenure_Level,
    COUNT("Customer ID") AS Customer_Count
FROM Customer_Tenure
GROUP BY Season, Category, Tenure_Level
ORDER BY Season, Category, Customer_Count DESC;

--QUESTION 3: Which geographies signal organic demand versus discount-driven volume?


SELECT 
    Location,
    SUM(CASE WHEN Promo_Segment = 'Organic' THEN 1 ELSE 0 END) AS Organic_Customer_Count,
    SUM(CASE WHEN Promo_Segment = 'Discount Dependent' THEN 1 ELSE 0 END) AS Discount_Driven_Count,
    SUM(CASE WHEN Promo_Segment = 'Organic' THEN "Purchase Amount (USD)" ELSE 0 END) AS Organic_Revenue,
    SUM(CASE WHEN Promo_Segment = 'Discount Dependent' THEN "Purchase Amount (USD)" ELSE 0 END) AS Discount_Revenue
FROM cleaned_customer_data
GROUP BY Location
ORDER BY Organic_Revenue DESC, Discount_Revenue DESC;

-- ============================================
-- QUESTION 4: How should the brand restructure its promotional strategy?
-- ============================================

-- 4a: Current state - Revenue by Promo Segment
SELECT 
    Promo_Segment,
    COUNT("Customer ID") AS Customer_Count,
    SUM("Purchase Amount (USD)") AS Total_Revenue,
    AVG("Purchase Amount (USD)") AS Avg_Order_Value,
    SUM("Purchase Amount (USD)") * 1.0 / SUM(SUM("Purchase Amount (USD)")) OVER() AS Revenue_Percentage
FROM cleaned_customer_data
GROUP BY Promo_Segment
ORDER BY Total_Revenue DESC;

-- 4b: Margin impact simulation (assuming 20% discount on promo-dependent purchases)
WITH Margin_Simulation AS (
    SELECT 
        Promo_Segment,
        SUM("Purchase Amount (USD)") AS Current_Revenue,
        CASE 
            WHEN Promo_Segment = 'Discount Dependent' THEN SUM("Purchase Amount (USD)") * 0.80  -- Remove discount, lose 20% volume
            ELSE SUM("Purchase Amount (USD)")
        END AS Projected_Revenue_After_Sunset,
        CASE 
            WHEN Promo_Segment = 'Discount Dependent' THEN SUM("Purchase Amount (USD)") * 0.20  -- Margin gain from removed discounts
            ELSE 0
        END AS Margin_Gain
    FROM cleaned_customer_data
    GROUP BY Promo_Segment
)
SELECT 
    Promo_Segment,
    Current_Revenue,
    Projected_Revenue_After_Sunset,
    Current_Revenue - Projected_Revenue_After_Sunset AS Revenue_Impact,
    Margin_Gain,
    Margin_Gain - (Current_Revenue - Projected_Revenue_After_Sunset) AS Net_Profit_Impact
FROM Margin_Simulation;

-- 4c: Recommended promo restructuring by segment
SELECT 
    Promo_Segment,
    Value_Tier,
    COUNT("Customer ID") AS Customer_Count,
    AVG("Purchase Amount (USD)") AS Avg_Spend,
    AVG("Previous Purchases") AS Avg_Loyalty,
    CASE 
        WHEN Value_Tier = 'High' AND Promo_Segment = 'Organic' THEN 'Sunset Discounts Immediately'
        WHEN Value_Tier = 'High' AND Promo_Segment = 'Moderate Promo' THEN 'Reduce Discounts by 50%'
        WHEN Value_Tier = 'Low' AND Promo_Segment = 'Discount Dependent' THEN 'Maintain but Cap Discounts'
        ELSE 'No Change'
    END AS Recommended_Action
FROM cleaned_customer_data
GROUP BY Promo_Segment, Value_Tier
ORDER BY Value_Tier DESC, Customer_Count DESC;


-- ============================================
-- QUESTION 5: What does the brand's ideal customer profile look like?
-- ============================================

-- 5a: Ideal Customer Profile (High Value + Loyal + Organic)
SELECT 
    'Ideal Customer Profile' AS Profile_Type,
    ROUND(AVG(Age), 0) AS Avg_Age,
    Gender,
    Location,
    Category,
    ROUND(AVG("Purchase Amount (USD)"), 0) AS Avg_Order_Value,
    ROUND(AVG("Previous Purchases"), 0) AS Avg_Frequency,
    COUNT("Customer ID") AS Sample_Size
FROM cleaned_customer_data
WHERE Value_Tier = 'High' 
  AND Retention_Segment = 'Loyal'
  AND Promo_Segment = 'Organic'
GROUP BY Gender, Location, Category
ORDER BY Avg_Order_Value DESC
LIMIT 10;

-- 5b: Top locations for organic high-value customers
SELECT 
    Location,
    COUNT("Customer ID") AS Organic_High_Value_Count,
    SUM("Purchase Amount (USD)") AS Total_Organic_Revenue,
    AVG("Purchase Amount (USD)") AS Avg_Order_Value,
    RANK() OVER (ORDER BY SUM("Purchase Amount (USD)") DESC) AS Revenue_Rank
FROM cleaned_customer_data
WHERE Value_Tier = 'High' AND Promo_Segment = 'Organic'
GROUP BY Location
ORDER BY Total_Organic_Revenue DESC
LIMIT 10;

-- 5c: Category preference of ideal customers
SELECT 
    Category,
    COUNT("Customer ID") AS Ideal_Customer_Count,
    SUM("Purchase Amount (USD)") AS Revenue_From_Ideal,
    AVG("Review Rating") AS Avg_Satisfaction,
    COUNT("Customer ID") * 100.0 / SUM(COUNT("Customer ID")) OVER() AS Percentage_of_Ideal_Base
FROM cleaned_customer_data
WHERE Value_Tier = 'High' AND Promo_Segment = 'Organic'
GROUP BY Category
ORDER BY Ideal_Customer_Count DESC;


-- ============================================
-- EXTRA: Promo Sunset Plan Supporting Query
-- ============================================

-- Identify candidates for promo sunset (High Value + Organic)
SELECT 
    "Customer ID",
    Age,
    Location,
    Category,
    "Purchase Amount (USD)",
    "Previous Purchases",
    CLV_Proxy,
    'Phase 1 Sunset' AS Recommended_Treatment,
    'Month 1' AS Rollout_Phase
FROM cleaned_customer_data
WHERE Value_Tier = 'High' AND Promo_Segment = 'Organic'
ORDER BY CLV_Proxy DESC
LIMIT 100;